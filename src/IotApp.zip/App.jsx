import { useEffect } from "react";
import AdminUI from "./routes/Admin";
import Menu from "./routes/Menu";
import TableOrder from "./routes/TableOrder";
import "./styles/App.css";
import {
  createBrowserRouter,
  RouterProvider,
  useNavigate,
} from "react-router-dom";
function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Menu />,
    },
    {
      path: "/menu/:id?",
      element: <Menu />,
    },
    {
      path: "/admin",
      element: <AdminUI />,
    },
    {
      path: "/order",
      element: <TableOrder />,
    },
  ]);
  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
